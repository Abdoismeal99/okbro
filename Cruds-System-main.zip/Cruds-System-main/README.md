# Cruds-System
Project CRUD System is a web application designed to perform Create, Read, Update, and Delete operations on a set of data. Developed using HTML, CSS, Bootstrap, JavaScript, and local storage, the application offers a user-friendly interface for managing and manipulating data.
